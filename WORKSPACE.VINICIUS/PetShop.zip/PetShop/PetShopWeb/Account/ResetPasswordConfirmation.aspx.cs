﻿using System.Web.UI;

namespace PetShopWeb.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}